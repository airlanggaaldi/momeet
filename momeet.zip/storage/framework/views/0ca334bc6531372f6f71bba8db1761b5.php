<?php $__env->startSection('content'); ?>
    <div class="wishlist-box-main">
        <div class="container">
            <h2><b>Data Kota</b></h2>
            <div class="row mt-2">
                <div class="table-main table-responsive">
                    <table class="table text-center table-hover" style="justify-content: space-between; text-align: center;">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Kota</th>
                                <th colspan="2">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 1 ?>
                            <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($no++); ?>

                                    </td>
                                    <td>
                                        <?php echo e($m->nama_kota); ?>

                                    </td>
                                    <td>
                                        <a class="badge badge-warning" href="<?php echo e(route('editKota', $m->id_kota)); ?>"><i
                                                class="bi bi-pencil-square"></i></a>
                                    </td>
                                    <td>
                                        <a class="badge badge-danger" href="<?php echo e(route('hapusKota', $m->id_kota)); ?>">
                                            <i class='bi bi-x-lg'></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <a class="btn hvr-hover" style="color: #ffffff" href="/add-kota">Tambah Kota</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\rangga\momeet\resources\views/kota.blade.php ENDPATH**/ ?>