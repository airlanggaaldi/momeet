<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h2><b>Admin Cek Order</b></h2>
        <div class="table-main table-responsive">
            <table class="table text-center table-hover">
                <thead>
                    <tr>
                        <th>Tanggal Contact</th>
                        <th>Email</th>
                        <th>Nama User</th>
                        <th>Pesan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $contact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($m->created_at); ?></td>
                            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($u->id == $m->id_user): ?>
                                    <td><?php echo e($u->email); ?></td>
                                    <td><?php echo e($u->username); ?></td>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e($m->pesan); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\rangga\momeet\resources\views/admin-contact.blade.php ENDPATH**/ ?>