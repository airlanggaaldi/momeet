<?php $__env->startSection('content'); ?>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"
        integrity="sha384-fbbOQedDUMZZ5KreZpsbe1LCZPVmfTnH7ois6mU1QK+m14rQ1l2bGBq41eYeM/fS" crossorigin="anonymous">
    </script>
    <div class="container">
        <div class="table-main table-responsive">
            <table class="table table-responsive-md table-hover mt-3 text-center">
                <thead>
                    <tr>
                        <th scope="col">Foto</th>
                        <th scope="col">Nama Tempat</th>
                        <th scope="col">Harga</th>
                        <th scope="col">Rating</th>
                        <th scope="col">Status</th>
                        <th scope="col">Ads</th>
                        <th scope="col">Data Order</th>
                        <th scope="col" colspan="2">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <img src="<?php echo e($m->gambar); ?>" alt="Image" width="100px">
                            </td>
                            <td><?php echo e("{$m->nama_properti}"); ?></td>
                            <td>Rp. <?php echo e("{$m->harga}"); ?></td>
                            <td>
                                <?php for($i = 0; $i < $m->rating; $i++): ?>
                                    <i class="bi bi-star-fill" style="color: rgb(255, 217, 0)"></i>
                                <?php endfor; ?>
                            </td>
                            <td>
                                <?php if($m->status == 'approved'): ?>
                                    <span class="badge badge-success"><?php echo e($m->status); ?></span>
                                <?php elseif($m->status == 'pending'): ?>
                                    <span class="badge badge-warning"><?php echo e($m->status); ?></span>
                                <?php elseif($m->status == 'reject'): ?>
                                    <span class="badge badge-danger"><?php echo e($m->status); ?></span>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($m->status == 'approved'): ?>
                                    
                                    <a class="btn btn-primary border-0" style="background-color: #8C52FF"
                                        href="<?php echo e(route('ads', $m->id_properti)); ?> ">Ads</a>
                                    
                                <?php else: ?>
                                    <button class="btn btn-primary border-0" style="background-color: #8C52FF"
                                        disabled>Ads</button>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($m->status == 'approved'): ?>
                                    <a class="btn btn-primary border-0" style="background-color: #8C52FF"
                                        href="<?php echo e(route('propertiOrder', $m->id_properti)); ?>">Order</a>
                                <?php else: ?>
                                    <button class="btn btn-primary border-0" style="background-color: #8C52FF"
                                        disabled>Order</button>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a class="badge badge-warning" href="<?php echo e(route('updateForm', $m->id_properti)); ?>"><i
                                        class="bi bi-pencil-square"></i></a>
                            </td>
                            <td>
                                
                                <a class="badge badge-danger" href="<?php echo e(route('hapus', $m->id_properti)); ?>">
                                    <i class='bi bi-x-lg'></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <a class="btn btn-primary" style="background-color: #8C52FF" href="/add-properties">Add Property</a>
        </div>
    </div>

    <!-- Modal -->
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\rangga\momeet\resources\views/properties.blade.php ENDPATH**/ ?>