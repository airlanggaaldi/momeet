<?php $__env->startSection('content'); ?>
    <div class="container mt-2">
        <h2><b>Approve Ads</b></h2>
        <div>
            <table class="table table-hover text-center">
                <thead class="thead">
                    <tr>
                        <th>Poster</th>
                        <th>Nama Properti</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <img src="<?php echo e($a->poster); ?>" alt=""
                                    style="width: 200px; height: 100px; object-fit: cover;">
                            </td>
                            <td>
                                <?php $__currentLoopData = $property; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($p->id_properti == $a->id_properti): ?>
                                        <?php echo e($p->nama_properti); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                                <?php if($a->status == 'pending'): ?>
                                    <a href="<?php echo e(route('approvingAds', $a->id_iklan)); ?>"
                                        class="badge badge-success">Approve</a>
                                    <a href="<?php echo e(route('rejectingAds', $a->id_iklan)); ?>" class="badge badge-danger">Reject</a>
                                <?php elseif($a->status == 'approve'): ?>
                                    <div class="badge badge-success"><?php echo e($a->status); ?></div>
                                <?php elseif($a->status == 'reject'): ?>
                                    <div class="badge badge-danger"><?php echo e($a->status); ?></div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(route('hapusAds', $a->id_iklan)); ?>" class="btn btn-danger">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\rangga\momeet\resources\views/admin-ads.blade.php ENDPATH**/ ?>