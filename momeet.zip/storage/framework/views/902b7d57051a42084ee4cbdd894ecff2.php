<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h2><b>Admin Cek Order</b></h2>
        <div class="table-main table-responsive">
            <table class="table text-center table-hover">
                <thead>
                    <tr>
                        <th>Tanggal Booking</th>
                        <th>Jam</th>
                        <th>Nama User</th>
                        <th>Nama Properti</th>
                        <th>Tanggal Pemesanan</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $propertiOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($m->tanggal); ?></td>
                            <td><?php echo e($m->jam); ?></td>
                            <td>
                                <?php $__currentLoopData = $userOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($u->id == $m->id_user): ?>
                                        <?php echo e($u->username); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td><?php echo e($m->properties->first()->nama_properti); ?></td>
                            <td><?php echo e($m->created_at); ?></td>
                            <td><?php echo e($m->status); ?></td>
                            <td>
                                <a class="badge badge-danger" href="<?php echo e(route('cancel', $m->id_order)); ?>">Cancel</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\rangga\momeet\resources\views/admin-order.blade.php ENDPATH**/ ?>