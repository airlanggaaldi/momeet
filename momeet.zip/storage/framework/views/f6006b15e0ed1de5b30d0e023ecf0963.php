<?php $__env->startSection('content'); ?>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"
        integrity="sha384-fbbOQedDUMZZ5KreZpsbe1LCZPVmfTnH7ois6mU1QK+m14rQ1l2bGBq41eYeM/fS" crossorigin="anonymous">
    </script>
    <div class="all-title-box">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2>Bookmark</h2>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="bookmark">Bookmark</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="container mt-5">
        <?php if(\Session::has('msgHapus')): ?>
            <div class="alert alert-success">
                <ul>
                    <li><?php echo \Session::get('msgHapus'); ?></li>
                </ul>
            </div>
        <?php endif; ?>
        <div class="table-main table-responsive">
            <table class="table table-responsive-md table-hover text-center">
                <thead>
                    <tr>
                        <th scope="col">Foto</th>
                        <th scope="col">Nama Tempat</th>
                        <th scope="col">Remove</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $bookmark; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $property; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($m->id_properti == $p->id_properti): ?>
                                <tr>
                                    <td>
                                        <img src="<?php echo e($p->gambar); ?>" alt=""
                                            style="width: 200px; height: 100px; object-fit: cover;">
                                    </td>
                                    <td><?php echo e($p->nama_properti); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('hapusBookmark', $p->id_properti)); ?>"><i
                                                class="bi bi-x-lg"></i></a>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            
        </div>
    </div>

    <!-- Modal -->
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\rangga\momeet\resources\views/bookmark.blade.php ENDPATH**/ ?>