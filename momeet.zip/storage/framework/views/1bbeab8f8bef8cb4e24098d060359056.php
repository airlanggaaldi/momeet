<?php $__env->startSection('content'); ?>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"
        integrity="sha384-fbbOQedDUMZZ5KreZpsbe1LCZPVmfTnH7ois6mU1QK+m14rQ1l2bGBq41eYeM/fS" crossorigin="anonymous">
    </script>
    <!-- Start Shop Detail  -->
    <div class="shop-detail-box-main ">
        <div class="container">
            <div class="row">
                <div class="col-xl-5 col-lg-5 col-md-6">
                    <div id="image" class="single-product-slider carousel slide" data-ride="carousel">
                        <div class="carousel-inner" role="listbox">
                            <div class="carousel-item active"> <img class="d-block w-100" src="<?php echo e($property->gambar); ?>"
                                    alt="First slide"> </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6">
                    <?php if(\Session::has('msg')): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <li><?php echo \Session::get('msg'); ?></li>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <?php if(\Session::has('msgAdd')): ?>
                        <div class="alert alert-success">
                            <ul>
                                <li><?php echo \Session::get('msgAdd'); ?></li>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <div class="single-product-details">
                        <h2><?php echo e($property->nama_properti); ?></h2>
                        <h5>
                            
                            Rp. <?php echo e(number_format($property->harga)); ?>

                        </h5>
                        <p class="available-stock"><span> Kapasitas: <?php echo e($property->kapasitas); ?></span>
                        <p>
                        <h4>Spesifikasi:</h4>
                        <p>
                            <?php echo e($property->deskripsi); ?>

                        </p>
                        <form class="newsletter-box" method="post"
                            action="<?php echo e(route('orderProperties', $property->id_properti)); ?>">
                            <?php echo csrf_field(); ?>
                            <ul style="width: 350px">
                                <li>
                                    <label class="control-label">Jadwal Booking</label>
                                    <div class="form-group quantity-box form-check-inline">
                                        <input class="form-control mr-1" value="0" min="0" max="20"
                                            type="date" name="tanggal" style="width: 180px">
                                        <select class="form-control" style="width: 130px"
                                            aria-label="Default select example" name="jam">
                                            <option selected>Jam Booking</option>
                                            <?php for($i = 8; $i <= 21; $i++): ?>
                                                <?php if($i < 10): ?>
                                                    <option value="0<?php echo e($i); ?>:00">0<?php echo e($i); ?>:00</option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($i); ?>:00"><?php echo e($i); ?>:00</option>
                                                <?php endif; ?>
                                            <?php endfor; ?>
                                        </select>
                                        
                                    </div>
                                </li>
                            </ul>
                            <button class="btn hvr-hover" style="color: #ffff" type="submit">Order</button>
                        </form>
                        <a class="btn hvr-hover mt-1" style="color: #ffff;" data-fancybox-close=""
                            href="<?php echo e(route('addBookmark', $property->id_properti)); ?>"><i class="fas fa-heart"></i>Add to
                            bookmark</a>
                        <div class="price-box-bar mt-2">
                            <div class="cart-and-bay-btn">
                                
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-6">
                    <table>
                        <thead>
                            <tr>
                                <th>

                                </th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
            <div class="row my-5">
                <div class="card card-outline-secondary my-4">
                    <div style="width: 1140px" class="card-header">
                        <h2>Property Reviews</h2>
                    </div>
                    <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($p->review != null || $p->review != ''): ?>
                            <div class="card-body" style="width: 1200px" back>
                                <div class="media">
                                    <div class="media-body mb-0">
                                        <p>
                                            <?php for($i = 0; $i < $p->rating; $i++): ?>
                                                <i class="bi bi-star-fill" style="color: rgb(255, 217, 0)"></i>
                                            <?php endfor; ?>
                                        </p>
                                        <p>
                                            <?php echo e($p->review); ?>

                                        </p>
                                        <small class="text-muted mb-0">
                                            Posted by
                                            <?php $__currentLoopData = $userOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($u->id == $p->id_user): ?>
                                                    <?php echo e($u->username); ?>

                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            on <?php echo e($p->updated_at); ?>

                                        </small>
                                    </div>
                                </div>
                            </div>
                            <hr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    <!-- End Cart -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\rangga\momeet\resources\views/booking.blade.php ENDPATH**/ ?>