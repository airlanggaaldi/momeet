<?php $__env->startSection('content'); ?>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"
        integrity="sha384-fbbOQedDUMZZ5KreZpsbe1LCZPVmfTnH7ois6mU1QK+m14rQ1l2bGBq41eYeM/fS" crossorigin="anonymous">
    </script>
    <div class="container">
        <h2>My Order</h2>
        <div class="table-main table-responsive">
            <table class="table text-center table-hover">
                <thead>
                    <tr>
                        <th>Tanggal Booking</th>
                        <th>Jam</th>
                        <th>Nama Properti</th>
                        <th>Tanggal Pemesanan</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $myOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($m->tanggal); ?></td>
                            <td><?php echo e($m->jam); ?></td>
                            <td><?php echo e($m->properties->first()->nama_properti); ?></td>
                            <td><?php echo e($m->created_at); ?></td>
                            <td><?php echo e($m->status); ?></td>
                            <td>
                                <?php if($m->status == 'accepted'): ?>
                                    <a class="btn btn-success" href="<?php echo e(route('review', $m->id_order)); ?>">End</a>
                                <?php elseif($m->status == 'pending'): ?>
                                    
                                    <button type="button" class="btn btn-primary border-0" style="background-color: #8C52FF"
                                        data-bs-toggle="modal" data-bs-target="#exampleModal"> Payment </button>
                                    
                                    <div class="modal fade" id="exampleModal" tabindex="-1"
                                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h1 class="modal-title fs-5" id="exampleModalLabel">Konfirmasi
                                                        Pembayaran</h1>
                                                    <button type="button" class="btn-close border-0"
                                                        data-bs-dismiss="modal" aria-label="Close"><i
                                                            class="bi bi-x"></i></button>
                                                </div>
                                                <div class="modal-body">
                                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($m->properties->first()->id_user == $u->id): ?>
                                                            <a href="https://wa.me/<?php echo e($u->nomor_telp); ?>"
                                                                target="_blank">KONFIRMASI
                                                                PEMBAYARAN ANDA</a>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-bs-dismiss="modal">Close</button>
                                                    <a class="btn btn-danger" style="color: white" href="">Hapus</a>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\rangga\momeet\resources\views/myOrder.blade.php ENDPATH**/ ?>