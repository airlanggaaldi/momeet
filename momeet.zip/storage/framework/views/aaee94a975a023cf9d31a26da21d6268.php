<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h2><b>Approve Properties</b></h2>
        <div class="row mt-2">
            <div class="col">
                <div class="table-main table-hover table-responsive">
                    <table class="table border-0" style="text-align: center;">
                        <thead>
                            <tr>
                                <th>Foto</th>
                                <th>Nama Tempat</th>
                                <th>Kapasitas </th>
                                <th>Jenis Properti </th>
                                <th>Deskripsi </th>
                                <th>Harga </th>
                                <th colspan="2">Approve</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="thumbnail-img">
                                        <img class="img-fluid" src="<?php echo e($m->gambar); ?>" alt="" width="100px" />
                                    </td>
                                    <td>
                                        <?php echo e($m->nama_properti); ?>

                                    </td>
                                    <td>
                                        <?php echo e($m->kapasitas); ?>

                                    </td>
                                    <td>
                                        <?php echo e($m->jenis_properti); ?>

                                    </td>
                                    <td>
                                        <?php echo e($m->deskripsi); ?>

                                    </td>
                                    <td>
                                        <?php echo e($m->harga); ?>

                                    </td>
                                    <?php if($m->status == 'approved'): ?>
                                        <td colspan="2">
                                            <span class="badge badge-success"><?php echo e($m->status); ?></span>
                                        </td>
                                    <?php elseif($m->status == 'reject'): ?>
                                        <td colspan="2">
                                            <span class="badge badge-danger"><?php echo e($m->status); ?></span>
                                        </td>
                                    <?php elseif($m->status == 'pending'): ?>
                                        <td>
                                            <a class="badge badge-success" href="<?php echo e(route('approve', $m->id_properti)); ?>"><i
                                                    class="bi bi-check2-square"></i></a>
                                        </td>
                                        <td>
                                            <a class="badge badge-danger" href="<?php echo e(route('reject', $m->id_properti)); ?>">
                                                <i class='bi bi-x-lg'></i>
                                            </a>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\rangga\momeet\resources\views/pending.blade.php ENDPATH**/ ?>